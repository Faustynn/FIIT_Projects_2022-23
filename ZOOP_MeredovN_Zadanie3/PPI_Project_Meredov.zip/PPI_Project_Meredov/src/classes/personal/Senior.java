package classes.personal;

public class Senior extends Service {
    public Senior(String nameSurname, int age, int salary, String individualLogin, String individualPass,String rank) {
        super(nameSurname, age, 2500,individualLogin,individualPass,"Senior");

    }
}