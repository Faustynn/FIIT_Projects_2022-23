package classes.personal;

public class Middle extends Service {
    public Middle(String nameSurname, int age, int salary, String individualLogin, String individualPass,String rank) {
        super(nameSurname, age, 1500,individualLogin,individualPass,"Middle");
    }
}