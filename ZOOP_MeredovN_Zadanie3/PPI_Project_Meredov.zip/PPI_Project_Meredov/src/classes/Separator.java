package classes;
import java.util.List;

abstract class Separator {
    public abstract List<String> separate(String input);
}