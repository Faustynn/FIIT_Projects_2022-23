package classes.hallclases;

public class Platinum extends Halls {
    // Konstructor pre Platinum
    public Platinum(double price, int numbofpl,int aktualpl, double expenses, int staffCount) {
        super(price, numbofpl, aktualpl, expenses, staffCount);

    }
    public Platinum(){
        super(20, 20,20, 6, 5);
    }






}