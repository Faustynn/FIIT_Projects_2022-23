package classes.hallclases;

public class Gold extends Halls {
    // Konstructor pre Gold
    public Gold(double price, int numbofpl,int aktualpl, double expenses, int staffCount) {
        super(price, numbofpl, aktualpl, expenses, staffCount);

    }
    public Gold(){
        super(15, 50,50, 5, 5);
    }






}